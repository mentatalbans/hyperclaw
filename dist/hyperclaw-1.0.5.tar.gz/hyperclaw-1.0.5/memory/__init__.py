# memory package — GIL long-term memory modules
