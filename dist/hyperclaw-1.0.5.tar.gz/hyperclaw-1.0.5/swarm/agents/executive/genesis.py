"""GENESIS — Self-expansion engine. Designs new agents, skills, and system capabilities."""
from __future__ import annotations
from swarm.agents.base import BaseAgent
from core.hyperstate.schema import HyperState


class GenesisAgent(BaseAgent):
    agent_id = "GENESIS"
    domain = "executive"
    description = "Self-expansion engine — designs new agents, skills, and system capabilities"
    supported_task_types = ["agent_design", "skill_creation", "system_expansion", "architecture"]
    preferred_model = "claude-opus-4-5"

    async def run(self, task: str, state: HyperState, context: dict) -> str:
        system = self._build_system(
            "You are GENESIS, the HyperClaw self-expansion engine. "
            "You design new agents, define new skill modules, and architect system expansions. "
            "When asked to create a new agent, produce a complete Python class following the BaseAgent pattern. "
            "When asked to create a skill, produce a complete skill module. "
            "All your outputs are production-ready — no placeholders, no TODOs. "
            "You are responsible for HyperClaw's growth and evolution."
        )
        result = await self.model_router.call(
            task_type="agent_design",
            messages=[{"role": "user", "content": task}],
            system=system,
            state=state,
        )
        await self.log_completion(state, result, self.preferred_model, bool(result))
        return result
